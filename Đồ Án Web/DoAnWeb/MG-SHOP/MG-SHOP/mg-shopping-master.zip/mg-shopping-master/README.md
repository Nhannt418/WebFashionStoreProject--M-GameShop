# MG-Shopping
Bản thảo mg-shopping
MG-shopping là một chương trình đầu tiên mình viết trên nền web mvc c#
Cấu tạo chương trình được khởi tạo bởi manhte
Do lần đâu viết nên có khá nhiều sai sót do vậy các module trong mg chỉ còn mang tính chất tham khảo
#Thời gian:1 tháng
#Người viết csdl:manhte// bị sai sót
#Người thiết kế font-end:manhte: có mượn 1 số ảnh và css trên mạng
#Người code các thành phần model: manhte
#Người viết chức năng: manh tể
#Người tạo trang admin và code: manhte
