﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MG_Model.CodeHandle.GaleryManager
{
    public class GaleryModel
    {
        public string image_large { get; set; }
        public string alt { get; set; }
        public string nameProduct { get; set; }
    }
}
