﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MG_Model.CodeHandle._adminHome
{
    public class _HomeModel
    {
            public int id { get; set; }
            public string nameCustomer { get; set; }
            public int? age { get; set; }
            public bool sex { get; set; }
            public string phoneNumber { get; set; }
            public string Email { get; set; }
            public int? countProduct { get; set; }
    }
}
