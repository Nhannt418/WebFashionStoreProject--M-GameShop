﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MG_SHOPPING.Models.Detail
{
    public class SearchModel
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}